angular.module('app.services', [])

.service('BlankService', [function(){

}]);